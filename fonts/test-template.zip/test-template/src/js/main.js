import './_components.js';
import './components/file.js';
import './components/range.js';
import './components/select.js';
import { burger } from './functions/burger.js';
