# test-template

> Используется Gulp 5. Тестировалось на node.js 20.12.2

